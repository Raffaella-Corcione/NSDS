# Evaluation lab - Node-RED

## Group number: 24

## Group members

- Capaccioni Chiara
- Corcione Raffaella
- Cusano Virgilio

## Description of message flows
The flow starts with the receipt of a message at a Telegram receiver node and splits into three different paths according to the type of message (QUERY, TRACK, REPORT). 
### QUERY
The QUERY sub-flow sends a query to the OpenWeatherMap server with the city and country specified by the user and obtains as a response a message with the weather data which it forwards to a function node. The function node assembles the response and then sends it to a text node connected to the Telegram sender.
### TRACK
The TRACK sub-flow writes the city information on a file whose name is the chatId of the user, where all the tracked cities for that specific user are stored. Then it sends back an acknowledgment.
### REPORT
The REPORT sub-flow reads from the file corresponding to the specific user the list of tracked cities, and executes a QUERY for each one. The responses to the queries are sent to the user.

## Extensions 
OpenWeatherMap, RedBot

## Resources
bot URL: http://t.me/Eval25bot
Telegram API key: 8566821520:AAG_UF1nZ22H86jhri8Wmew4bRQgVtS6SdQ