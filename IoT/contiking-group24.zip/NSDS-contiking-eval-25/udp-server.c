/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of the Contiki operating system.
 *
 */

#include "contiki.h"
#include "net/routing/routing.h"
#include "net/netstack.h"
#include "net/ipv6/simple-udp.h"

#include "sys/log.h"
#define LOG_MODULE "App"
#define LOG_LEVEL LOG_LEVEL_INFO

#define WITH_SERVER_REPLY  1
#define UDP_CLIENT_PORT	8765
#define UDP_SERVER_PORT	5678

static struct simple_udp_connection udp_conn;

PROCESS(udp_server_process, "UDP server");
PROCESS(lock_process, "Lock process");
AUTOSTART_PROCESSES(&udp_server_process, &lock_process);
/*---------------------------------------------------------------------------*/
// Initialize data structure
static unsigned data_structure = 2;
static uip_ipaddr_t client_lock;
static struct ctimer lock_timer;
static uip_ipaddr_t default_addr;
static process_event_t acquired_lock;

static void lock(uip_ipaddr_t *sender) {
  if(uip_ipaddr_cmp(&client_lock, &default_addr)){
    // The lock is free
    uip_ipaddr_copy(&client_lock, sender);
    process_post(&lock_process, acquired_lock, NULL);
    return;
  }
  return;
}

static void write(uip_ipaddr_t *sender, unsigned value) {
  if(uip_ipaddr_cmp(&client_lock, sender)){
    LOG_INFO("Performing write with value %u\n", value);
    // The client holds the lock
    data_structure = value;
    ctimer_stop(&lock_timer);
    return;
  } else {
    unsigned response = 0; 
    simple_udp_sendto(&udp_conn, &response, sizeof(response), sender);
    return;
  }
}

static void read(uip_ipaddr_t *sender) {
  unsigned response = data_structure;
  simple_udp_sendto(&udp_conn, &response, sizeof(response), sender);
}

static void ctimer_callback(void *data){
  LOG_INFO("Lock timer expired, releasing lock\n");
  uip_ipaddr_copy(&client_lock, &default_addr);
}

static void
udp_rx_callback(struct simple_udp_connection *c,
         const uip_ipaddr_t *sender_addr,
         uint16_t sender_port,
         const uip_ipaddr_t *receiver_addr,
         uint16_t receiver_port,
         const uint8_t *data,
         uint16_t datalen)
{
  unsigned operation = *(unsigned *)data;

  switch(operation){
    case 0: // Lock request
      LOG_INFO("Received lock request from ");
      LOG_INFO_6ADDR(sender_addr);
      LOG_INFO_("\n");
      lock((uip_ipaddr_t *)sender_addr);
      break;
    case 1: // Read request
      LOG_INFO("Received read request from ");
      LOG_INFO_6ADDR(sender_addr);
      LOG_INFO_("\n");
      read((uip_ipaddr_t *)sender_addr);
      break;
    default: // Write request
      LOG_INFO("Received write request from ");
      LOG_INFO_6ADDR(sender_addr);
      LOG_INFO_("\n");
      write((uip_ipaddr_t *)sender_addr, operation);
      break;
  }
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(udp_server_process, ev, data)
{
  PROCESS_BEGIN();
  // Initialize the lock on a default value
  NETSTACK_ROUTING.get_root_ipaddr(&default_addr);
  uip_ipaddr_copy(&client_lock, &default_addr);
  acquired_lock = process_alloc_event();

  /* Initialize DAG root */
  NETSTACK_ROUTING.root_start();

  /* Initialize UDP connection */
  simple_udp_register(&udp_conn, UDP_SERVER_PORT, NULL,
                      UDP_CLIENT_PORT, udp_rx_callback);

  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(lock_process, ev, data)
{
  PROCESS_BEGIN();

  while(1){

    PROCESS_WAIT_EVENT_UNTIL(ev == acquired_lock);

    ctimer_set(&lock_timer, CLOCK_SECOND * 5, ctimer_callback, NULL);

  }

  PROCESS_END();
}