# Evaluation lab - Contiki-NG

## Group number: 24

## Group members

- Student 1 Chiara Capaccioni
- Student 2 Raffaella Corcione
- Student 3 Virgilio Cusano

## Solution description
Client Side:
We define a message that is a unsigned that represents the operation that the client want to perform.

0: lock
1: write
2: read

Every 10 seconds the client sends a message to servers. 
For testing the system we used a vector of integer where each element represents the operation to do at that specific time.
The sequence we test is:  0 -> 1 -> 2 -> 1 -> 2

Server Side:

The server has two protothread and it has a data_structure that can acquire only positive value higer or equal to 2. 
The data_structure is the one in which we perform read and write operations. 

One managed the receiving of the messages from the client.
When a message arrives the callback is triggered. 
Inside the function we have a switch based on the operation received:

- Read: the correct value to read is send back to the client.

- Lock: It checks if it can be aquired. In case is true, it post the event lock_acquire that wakes up the other protothread. This process will setup the ctimer lock_timer at 5s. If the ctimer expired the callback will reset the lock.

- Write: It checks if the client has the right to do that. In case is ok, the write is performed and the lock_timer is stopped and the lock is released. Otherwise an error message is send back to the client beacuse it didn't acquire a lock.





